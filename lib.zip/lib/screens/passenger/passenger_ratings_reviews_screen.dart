import 'package:testtale3/theme/app_styles.dart';
import 'package:flutter/material.dart';
import 'package:testtale3/l10n/app_localizations.dart';

class RatingsReviewsScreen extends StatelessWidget {
  const RatingsReviewsScreen({super.key});

  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: context.colors.textPrimary),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          context.l10n.ratingsAndReviews,
          style: TextStyle(
            color: context.colors.textPrimary,
            fontSize: 16,
            fontWeight: FontWeight.w800,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            children: [
              // Rating Overview
              Container(
                color: context.colors.surfaceColor,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
                child: Row(
                  children: [
                    // Big Score
                    Column(
                      children: [
                        Text(
                          '4.8',
                          style: TextStyle(
                            fontSize: 48,
                            fontWeight: FontWeight.w800,
                            color: context.colors.textPrimary,
                            height: 1,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: List.generate(5, (index) {
                            return Icon(
                              index < 4 ? Icons.star : Icons.star_half,
                              color: AppStyles.starRatingColor,
                              size: 16,
                            );
                          }),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '1,418 ${context.l10n.reviewsLabel}',
                          style: TextStyle(
                            fontSize: 12,
                            color: context.colors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(width: 32),
                    // Distribution Bars
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          _buildDistributionBar(context, 5, 0.8),
                          _buildDistributionBar(context, 4, 0.15),
                          _buildDistributionBar(context, 3, 0.03),
                          _buildDistributionBar(context, 2, 0.01),
                          _buildDistributionBar(context, 1, 0.01),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // Reviews Header
              Container(
                color: context.colors.surfaceColor,
                padding: const EdgeInsets.all(20),
                width: double.infinity,
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          context.l10n.passengerFeedback,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            color: context.colors.textPrimary,
                          ),
                        ),
                        Row(
                          children: [
                            Text(
                              context.l10n.sortBy,
                              style: TextStyle(
                                fontSize: 13,
                                color: context.colors.textSecondary,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              context.l10n.newest,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                color: AppStyles.primaryColor,
                              ),
                            ),
                            Icon(Icons.keyboard_arrow_down, color: AppStyles.primaryColor, size: 16),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    
                    // Reviews List
                    _buildReviewItem(context,
                      'Sarah Jenkins',
                      '1 day ago',
                      5.0,
                      'The driver was incredibly polite and drove very safely. The car was incredibly clean and smelling very nice! Highly recommend.',
                      12,
                    ),
                    Divider(height: 32, color: context.colors.dividerColor),
                    _buildReviewItem(context,
                      'Thomas Khalil',
                      '3 days ago',
                      4.0,
                      'Good ride, cheap booking online, my route changed and driver cooperated however air conditioning was a bit weak in the back.',
                      4,
                    ),
                    Divider(height: 32, color: context.colors.dividerColor),
                    _buildReviewItem(context,
                      'Aisha Al-Saidi',
                      '1 week ago',
                      5.0,
                      'Hassan is definitely the best! Very friendly and professional! We arrived on time! Can\'t represent better services!',
                      15,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),

      // Bottom Navigation
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: context.colors.surfaceColor,
          border: Border(top: BorderSide(color: context.colors.borderColor, width: 1)),
        ),
        child: BottomNavigationBar(
          currentIndex: 3, // Since it reviews driver, let's keep it generally on profile or unselected
          type: BottomNavigationBarType.fixed,
          backgroundColor: context.colors.surfaceColor,
          selectedItemColor: AppStyles.primaryColor,
          unselectedItemColor: context.colors.textTertiary,
          selectedFontSize: 10,
          unselectedFontSize: 10,
          elevation: 0,
          items: [
            BottomNavigationBarItem(
              icon: const Icon(Icons.home_outlined),
              activeIcon: const Icon(Icons.home),
              label: context.l10n.home.toUpperCase(),
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.history_outlined),
              activeIcon: const Icon(Icons.history),
              label: context.l10n.myTrips.toUpperCase(),
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.chat_bubble_outline),
              activeIcon: const Icon(Icons.chat_bubble),
              label: context.l10n.chat.toUpperCase(),
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.person_outline),
              activeIcon: const Icon(Icons.person),
              label: context.l10n.profile.toUpperCase(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDistributionBar(BuildContext context, int stars, double percentage) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 12,
            child: Text(
              stars.toString(),
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: context.colors.textSecondary,
              ),
            ),
          ),
          const SizedBox(width: 4),
          Icon(Icons.star, color: context.colors.textSecondary, size: 10),
          const SizedBox(width: 8),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: percentage,
                backgroundColor: context.colors.cardBackgroundColor,
                valueColor: AlwaysStoppedAnimation<Color>(AppStyles.primaryColor),
                minHeight: 6,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReviewItem(BuildContext context, String name, String time, double rating, String comment, int helpfulCount) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CircleAvatar(
              radius: 16,
              backgroundColor: context.colors.cardBackgroundColor,
              child: Text(
                name[0].toUpperCase(),
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: AppStyles.primaryColor,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: context.colors.textPrimary,
                    ),
                  ),
                  Text(
                    time,
                    style: TextStyle(
                      fontSize: 11,
                      color: context.colors.textTertiary,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: AppStyles.starRatingLightBg,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Icon(Icons.star, color: AppStyles.starRatingColor, size: 12),
                  const SizedBox(width: 4),
                  Text(
                    rating.toString(),
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: AppStyles.starRatingDarkText,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          comment,
          style: TextStyle(
            fontSize: 14,
            color: context.colors.textDeep,
            height: 1.5,
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            _buildHelpfulAction(context, Icons.thumb_up_outlined, helpfulCount.toString()),
            const SizedBox(width: 16),
            _buildHelpfulAction(context, Icons.thumb_down_outlined, ''),
          ],
        ),
      ],
    );
  }

  Widget _buildHelpfulAction(BuildContext context, IconData icon, String label) {
    return Row(
      children: [
        Icon(icon, color: context.colors.textTertiary, size: 16),
        if (label.isNotEmpty) ...[
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: context.colors.textSecondary,
            ),
          ),
        ],
      ],
    );
  }
}

